# Purpur Export (Fabric)

ワールドを vanilla/Fabric 形式 → Purpur(Paper) 形式に変換して `<gameDir>/purpur_export/<日時>/` に出力します。

```
world/               <- level.dat, region, entities, poi, data, playerdata ...
world_nether/DIM-1/  <- region, entities, poi, data (+ level.dat)
world_the_end/DIM1/  <- region, entities, poi, data (+ level.dat)
```

## ビルド
GitHub に push → Actions の artifact から jar を取得。

## 使い方
- Mod: ゲーム/サーバー内で `/purpurexport` (OP権限)
  - `-Dpurpurexport.onstop=true` を付けるとサーバー停止時に自動出力
- スクリプト(ゲーム停止中): `scripts/run.sh <ワールドフォルダ>` / `scripts\run.bat <ワールドフォルダ>`

カスタムディメンション(`dimensions/`)は Paper でも同じ場所なのでそのままコピーされます。
