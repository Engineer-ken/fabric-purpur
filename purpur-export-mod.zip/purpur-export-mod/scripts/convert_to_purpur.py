#!/usr/bin/env python3
"""Fabric(vanilla) ワールド -> Purpur(Paper) 形式 変換スクリプト (ゲーム停止中に実行)

使い方: python3 convert_to_purpur.py <ワールドフォルダ> [出力先=./purpur_export] [ワールド名]
"""
import sys, shutil, datetime
from pathlib import Path

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    src = Path(sys.argv[1]).resolve()
    base = Path(sys.argv[2] if len(sys.argv) > 2 else "purpur_export").resolve()
    name = sys.argv[3] if len(sys.argv) > 3 else src.name
    if not (src / "level.dat").exists():
        sys.exit(f"level.dat が見つかりません: {src}")
    if src in base.parents or src == base:
        sys.exit("出力先をワールドフォルダの外にしてください")

    out = base / datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    ignore = shutil.ignore_patterns("session.lock")

    def skip_top(d, names):
        ex = {"DIM-1", "DIM1", "session.lock"} if Path(d) == src else {"session.lock"}
        return [n for n in names if n in ex]

    shutil.copytree(src, out / name, ignore=skip_top)
    for dim, suffix in (("DIM-1", "_nether"), ("DIM1", "_the_end")):
        if (src / dim).is_dir():
            dst = out / (name + suffix)
            shutil.copytree(src / dim, dst / dim, ignore=ignore)
            shutil.copy2(src / "level.dat", dst / "level.dat")
    print(f"完了: {out}")

if __name__ == "__main__":
    main()
