package com.example.purpurexport;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

/**
 * vanilla/Fabric 形式:
 *   world/{level.dat, region, DIM-1/, DIM1/, ...}
 * Purpur(Paper) 形式:
 *   world/              (オーバーワールド)
 *   world_nether/DIM-1/ (ネザー)
 *   world_the_end/DIM1/ (エンド)
 */
public final class WorldConverter {
    private WorldConverter() {}

    public static Path convert(Path src, Path outBase, String name) throws IOException {
        src = src.toAbsolutePath().normalize();
        outBase = outBase.toAbsolutePath().normalize();
        if (outBase.startsWith(src)) {
            throw new IOException("出力先がワールドフォルダの内側です: " + outBase);
        }
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Path out = outBase.resolve(stamp);

        // オーバーワールド (DIM-1 / DIM1 を除く)
        copyTree(src, out.resolve(name), Set.of("DIM-1", "DIM1"));

        // ネザー
        Path nether = src.resolve("DIM-1");
        if (Files.isDirectory(nether)) {
            Path dst = out.resolve(name + "_nether");
            copyTree(nether, dst.resolve("DIM-1"), Set.of());
            copyIfExists(src.resolve("level.dat"), dst.resolve("level.dat"));
        }

        // エンド
        Path end = src.resolve("DIM1");
        if (Files.isDirectory(end)) {
            Path dst = out.resolve(name + "_the_end");
            copyTree(end, dst.resolve("DIM1"), Set.of());
            copyIfExists(src.resolve("level.dat"), dst.resolve("level.dat"));
        }
        return out;
    }

    private static void copyIfExists(Path from, Path to) throws IOException {
        if (Files.exists(from)) {
            Files.createDirectories(to.getParent());
            Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void copyTree(Path from, Path to, Set<String> skipTopDirs) throws IOException {
        Files.walkFileTree(from, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException {
                if (!dir.equals(from) && dir.getParent().equals(from)
                        && skipTopDirs.contains(dir.getFileName().toString())) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                Files.createDirectories(to.resolve(from.relativize(dir).toString()));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes a) throws IOException {
                if (file.getFileName().toString().equals("session.lock")) return FileVisitResult.CONTINUE;
                Files.copy(file, to.resolve(from.relativize(file).toString()),
                        StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
