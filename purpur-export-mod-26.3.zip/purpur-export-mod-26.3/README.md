# Purpur Export (Fabric 26.3)

Fabric 26.3 のワールドを `<gameDir>/purpur_export/<日時>/<ワールド名>/` に出力します。
26.1以降はバニラとPaper/Purpurの構造がほぼ同じなので、session.lock を除いてコピーするだけです。
Purpur側が起動時に自動で移行します。

使い方: Purpurの level-name を出力フォルダ名に合わせ、フォルダごとサーバーに置いて起動。

- `/purpurexport` (オーナー権限)
- `-Dpurpurexport.onstop=true` でサーバー停止時に自動出力
- スクリプト: `scripts/run.sh` / `scripts\run.bat` <ワールドフォルダ>

Java 25 / Fabric Loader 0.20.1+ / Fabric API 0.165.0+26.3 以上が必要です。
