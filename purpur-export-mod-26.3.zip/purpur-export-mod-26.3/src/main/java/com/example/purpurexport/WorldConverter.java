package com.example.purpurexport;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Minecraft 26.1 以降、バニラ(Fabric)と Paper/Purpur のワールド構造はほぼ同じ:
 *   <world>/level.dat
 *   <world>/dimensions/minecraft/{overworld,the_nether,the_end}/{region,entities,poi,data}
 *   <world>/data/  <world>/players/{data,advancements,stats}
 * Paper側が起動時に自動で移行するため、session.lock を除いてコピーするだけで良い。
 */
public final class WorldConverter {
    private WorldConverter() {}

    public static Path export(Path src, Path outBase, String name) throws IOException {
        src = src.toAbsolutePath().normalize();
        outBase = outBase.toAbsolutePath().normalize();
        if (outBase.startsWith(src)) {
            throw new IOException("出力先がワールドフォルダの内側です: " + outBase);
        }
        if (!Files.isDirectory(src.resolve("dimensions"))) {
            throw new IOException("26.x形式のワールド(dimensionsフォルダ)ではありません: " + src);
        }
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Path dst = outBase.resolve(stamp).resolve(name);
        final Path from = src;

        Files.walkFileTree(from, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException {
                Files.createDirectories(dst.resolve(from.relativize(dir).toString()));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes a) throws IOException {
                if (file.getFileName().toString().equals("session.lock")) return FileVisitResult.CONTINUE;
                Files.copy(file, dst.resolve(from.relativize(file).toString()),
                        StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
        return dst;
    }
}
