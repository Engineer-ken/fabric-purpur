package com.example.purpurexport;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

public class PurpurExportMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("purpurexport");

    @Override
    public void onInitialize() {
        // /purpurexport  (オーナー権限 / シングルプレイならチートON)
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) ->
                dispatcher.register(Commands.literal("purpurexport")
                        .requires(Commands.hasPermission(Commands.LEVEL_OWNERS))
                        .executes(ctx -> run(ctx.getSource()))));

        // JVM引数 -Dpurpurexport.onstop=true で、サーバー停止時に自動出力
        if (Boolean.getBoolean("purpurexport.onstop")) {
            ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
                try {
                    LOGGER.info("出力しました: {}", export(server));
                } catch (Exception e) {
                    LOGGER.error("出力に失敗しました", e);
                }
            });
        }
    }

    private static int run(CommandSourceStack src) {
        MinecraftServer server = src.getServer();
        src.sendSuccess(() -> Component.literal("[PurpurExport] 保存してコピー中..."), true);
        try {
            server.saveEverything(true, true, true);
            Path out = export(server);
            src.sendSuccess(() -> Component.literal("[PurpurExport] 完了: " + out), true);
            return 1;
        } catch (Exception e) {
            LOGGER.error("出力に失敗しました", e);
            src.sendFailure(Component.literal("[PurpurExport] 失敗: " + e.getMessage()));
            return 0;
        }
    }

    private static Path export(MinecraftServer server) throws Exception {
        Path root = server.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize();
        String name = root.getFileName().toString().replaceAll("[^A-Za-z0-9_\\-]", "_");
        Path outBase = FabricLoader.getInstance().getGameDir().resolve("purpur_export");
        return WorldConverter.export(root, outBase, name);
    }
}
