#!/usr/bin/env bash
# 使い方: ./run.sh <ワールドフォルダ> [出力先] [ワールド名]
set -e
cd "$(dirname "$0")"
python3 convert_to_purpur.py "$@"
