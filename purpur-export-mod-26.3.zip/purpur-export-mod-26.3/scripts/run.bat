@echo off
rem 使い方: run.bat <ワールドフォルダ> [出力先] [ワールド名]
cd /d "%~dp0"
python convert_to_purpur.py %*
pause
